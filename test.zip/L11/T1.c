#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char** argv)
{
    MPI_Init(&argc, &argv);

    int rank;
    int data = rand()%100; // for err checking
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // get rank of process

    if (rank == 0) // root 
    {
        data = 100; 
    }

    // &data: Pointer to the data being broadcast, 
    // 1: Number of elements to broadcast, 
    // MPI_INT: Data type (integer), 
    // 0: Root process rank, 
    // MPI_COMM_WORLD: Communicator.
    MPI_Bcast(&data, 1, MPI_INT, 0, MPI_COMM_WORLD);

    printf("Process %d received value %d\n", rank, data);

    MPI_Finalize();
    return 0;
}