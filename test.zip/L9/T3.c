#include <mpi.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);

    int rank, size, number;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Define the last process
    int last_process = size - 1;

    if (rank == last_process) // The last process initializes the number
    {

        number = 5;
        printf("Process %d: Starting number is %d, multiplied by %d, sending %d\n",
               rank, number, rank, number * rank);
        number *= rank;
        MPI_Send(&number, 1, MPI_INT, rank - 1, 0, MPI_COMM_WORLD);
    }
    else if (rank == 0) // Process 0 receives the final number and prints the result
    {

        MPI_Recv(&number, 1, MPI_INT, rank + 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process %d: Received %d\n", rank, number);
    }
    else // Intermediate processes receive, multiply, and send the number
    {

        MPI_Recv(&number, 1, MPI_INT, rank + 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process %d: Received %d, multiplied by %d, sending %d\n",
               rank, number, rank, number * rank);
        number *= rank;
        MPI_Send(&number, 1, MPI_INT, rank - 1, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize();

    return 0;
}
