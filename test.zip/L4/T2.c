#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_CARS 4 // num threads
#define NUM_CHECKPOINTS 5

pthread_barrier_t barrier;

void *car_function(void *arg)
{
    long car_number = (long)arg;
    for (int i = 0; i < NUM_CHECKPOINTS; i++)
    {
        printf("Car %ld reached checkpoint %d\n", car_number, i + 1);
        pthread_barrier_wait(&barrier);
    }

    printf("Car %ld finished the race\n", car_number);
    return NULL;
}

int main()
{
    pthread_t cars[NUM_CARS];

    pthread_barrier_init(&barrier, NULL, NUM_CARS); // barrier waits for NUM_CARS

    for (int i = 0; i < NUM_CARS; i++)
    {
        pthread_create(&cars[i], NULL, car_function, (void *)(long)i + 1);
    }

    for (int i = 0; i < NUM_CARS; i++)
    {
        pthread_join(cars[i], NULL);
    }

    pthread_barrier_destroy(&barrier);

    return 0;
}