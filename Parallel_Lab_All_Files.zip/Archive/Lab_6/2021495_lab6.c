#include <omp.h>
#include <stdio.h>

int min(int a, int b)
{
    return (a < b ? a : b);
}

int main()
{
    omp_set_num_threads(2);
    const int N = 1000;         // range size
    const int P = (N + 1) / 2; // partitions size N/2

    int count = 0; // total count

// create multiple threads
#pragma omp parallel
    {

        // making 2 sections, each operating on 1 half of range
#pragma omp sections
        {

            // first half
#pragma omp section
            {
                int cnt = 0;
                for (int j = 0; j < N / 2; j++)
                {
                    if (j < 2) continue;

                    int fl = 1;
                    for (int k = 2; k * k <= j; k++)
                    {
                        fl &= j % k > 0;
                    }

                    if (fl) cnt++;
                }

// mutual exclusion operation on shared variable
#pragma omp critical
                {
                    count += cnt;
                }

                printf("Thread %d, section 1, count %d \n", omp_get_thread_num(), cnt);
            }

            // second half
#pragma omp section
            {
                int cnt = 0;
                for (int j = N / 2; j <= N; j++)
                {
                    if (j < 2) continue;

                    int fl = 1;
                    for (int k = 2; k * k <= j; k++)
                    {
                        fl &= j % k > 0;
                    }

                    if (fl) cnt++;
                }

// mutual exclusion operation on shared variable
#pragma omp critical
                {
                    count += cnt;
                }

                printf("Thread %d, section 2, count %d \n", omp_get_thread_num(), cnt);
            }
        }

// synchronize all sections
#pragma omp barrier
    }

    printf("Total Count of Primes: %d \n", count);
}