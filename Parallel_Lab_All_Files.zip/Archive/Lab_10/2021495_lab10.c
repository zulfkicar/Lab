#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

long read_words(const char *filename, int L, int n, int last)
{
    FILE *file = fopen(filename, "r");
    if (!file)
    {
        fprintf(stderr, "Error opening file: %s\n", filename);
        exit(EXIT_FAILURE);
    }

    // Move the file pointer to the specified index
    if (fseek(file, L, SEEK_SET) != 0)
    {
        fprintf(stderr, "Error seeking to position %d in file.\n", L);
        fclose(file);
        exit(EXIT_FAILURE);
    }

    // Allocate memory to store the characters
    char *buffer = (char *)malloc(n + 1 + last); // +1 for null terminator
    if (!buffer)
    {
        fprintf(stderr, "Memory allocation failed.\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    // Read the specified number of characters
    size_t chars_read = fread(buffer, sizeof(char), n, file);
    if(last) buffer[chars_read] = '\n';
    buffer[chars_read + last] = '\0'; // Null-terminate the string

    int cnt = 0;
    for (int i = 0; i < chars_read + 1 + last; i++)
    {
        int found_white_space = 0;
        while (buffer[i] == ' ' || buffer[i] == '\n')
        {
            found_white_space = 1;
            i++;
        }

        if (found_white_space)
        {
            cnt++;
            i--;
        }
    }

    // printf("Read characters: %s\n", buffer);
    // printf("Read words: %d\n", cnt);
    return cnt;

    // Cleanup
    free(buffer);
    fclose(file);
}

long get_file_size(const char *filename)
{
    FILE *file = fopen(filename, "r");
    if (!file)
    {
        fprintf(stderr, "Error opening file: %s\n", filename);
        exit(EXIT_FAILURE);
    }

    if (fseek(file, 0, SEEK_END) != 0)
    {
        fprintf(stderr, "Error seeking to the end of the file.\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    long size = ftell(file);
    if (size == -1L)
    {
        fprintf(stderr, "Error getting the file size.\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    fclose(file);
    return size;
}

int main()
{
    const char *filename = "text.txt";
    int filesize = get_file_size(filename);

    MPI_Init(NULL, NULL);
    int rank;
    int size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int L = filesize / size * rank; // Starting index
    int n = filesize / size;        // Number of characters to read

    int cnt = read_words(filename, L, n, rank == size - 1);
    printf("Rank %d has read words: %d\n", rank, cnt);

    if (rank == 0)
    {
        int tmp_cnt = 0;
        for (int i = 1; i < size; i++)
        {
            // receive count from each process
            MPI_Recv(&tmp_cnt, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            cnt += tmp_cnt;
        }

        printf("Total count of words: %d\n", cnt);
    }
    else
    {
        MPI_Send(&cnt, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}
