#include<stdio.h>
#include<omp.h>

int min(int a, int b){
    return (a < b ? a : b);
}

int main(){
    omp_set_num_threads(4);
    const int N = 1000;         // array size
    const int P = 100;          // partitions of size 100

    int array[N];
    int tsum = 0;               // total sum
    
    // initialize
    for(int i = 0; i < N; i++)
    {
        array[i] = i + 1;
    }

    // create multiple threads
    #pragma omp parallel
    {
        // only 1 thread will create tasks
        #pragma omp single
        {
            for(int i = 0; i < N; i += P)
            {
                int end = min(i + P, N);
                // task created, this will be executed by any available thread
                #pragma omp task firstprivate(i)
                {
                    int sum = 0;
                    for(int j = i; j < end; j++){
                        sum += array[j];
                    }

                    // mutual exclusion operation on shared variable
                    #pragma omp atomic
                    tsum += sum;

                    printf("Thread %d, partition %d, sum %d \n", omp_get_thread_num(), i, sum);
                }
            }
            // the single thread will wait for all other threads
            #pragma omp taskwait
        }
    }
    printf("Total Expected Sum: %d \n", N*(N+1)/2);
    printf("Total Calculated Sum: %d \n", tsum);
}