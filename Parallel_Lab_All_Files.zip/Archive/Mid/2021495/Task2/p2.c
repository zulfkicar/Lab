#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<time.h>

int balance;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void *performTransaction(void * arg){
    // Transaction value btw -500 to -100 and 100 to 500
    int transaction = 100 + rand() % 401;
    if(rand() % 2) transaction = -transaction;

    printf("Performing transaction of %d\n", transaction);

    pthread_mutex_lock(&mutex);
    printf("BEFORE: %d\n", balance);
    pthread_mutex_unlock(&mutex);

    // Handle invalid transactions
    if(balance + transaction < 0){
        printf("UNABLE to make transaction because balance is LOW\n\n");
        return NULL;
    }

    // perform transaction
    pthread_mutex_lock(&mutex);
    balance += transaction;
    printf("AFTER: %d\n\n", balance);
    pthread_mutex_unlock(&mutex);
}

int main(){
    srand(time(NULL));
    do{
        printf("Enter balance of user: ");
        scanf("%d", &balance);
    } while(balance < 0);

    int numthreads;
    do{
        printf("Enter num of transactions : ");
        scanf("%d", &numthreads);
    } while(numthreads < 1);

    pthread_t threads[numthreads];
    for(int i = 0; i < numthreads; i++){
        pthread_create(&threads[i], NULL, performTransaction, NULL);
    }

    for(int i = 0; i < numthreads; i++){
        pthread_join(threads[i], NULL);
    }

    printf("Final balance: %d\n", balance);
    return 0;
}