#include<stdio.h>
#include<omp.h>
#include<time.h>
#include<stdlib.h>

int main(){
    omp_set_num_threads(4);

    printf("NxN image btw 5x5 and 100x100\n");
    int n;
    do{
        printf("Enter N: ");
        scanf("%d", &n);
    } while(n < 5 || n > 100);

    srand(time(NULL));
    int a[n][n];

    // initializing image, the value is kept < 10 for easier checking, it can be upto 255 for images.
    for(int i = 0; i < n; i++){
        for(int j = 0 ; j < n; j++){
            a[i][j] = rand()%10;
        }
    }

    // this is the image after blur filter is applied
    float b[n][n];

    #pragma omp parallel
    {
        #pragma omp single
        {
            for(int i = 0; i < n; i++){
                for(int j = 0; j < n; j++){
                    #pragma omp task firstprivate(i) firstprivate(j)
                    {
                        int avg = 0;
                        int cnt = 0;
                        // all border cases are handled properly
                        if(i > 0) avg += a[i-1][j], cnt++;
                        if(j > 0) avg += a[i][j-1], cnt++;
                        if(j < n-1) avg += a[i][j+1], cnt++;
                        if(i < n-1) avg += a[i+1][j], cnt++;
                        
                        #pragma omp critical
                            b[i][j] = avg*1.0/cnt;
                    }
                }
            }

            #pragma omp taskwait
        }
    }

    printf("a = \n");
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            printf("%d ", a[i][j]);
        } printf("\n");
    } printf("\n");

    printf("b = \n");
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            printf("%.2f ", b[i][j]);
        } printf("\n");
    }

    return 0;
}