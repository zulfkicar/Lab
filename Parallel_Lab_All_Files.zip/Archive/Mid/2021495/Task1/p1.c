#include<stdio.h>
#include<pthread.h>
#include<stdbool.h>
#include<unistd.h>

int size;
int ti, tj;
char grid[100][100];
bool found = false;
int firstThreadRow = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_barrier_t barrier;

void *searchGrid(void * arg){
    int row = *((int *) arg);
    printf("\nThread initialized on row %d\n", row);
    for(int i = row; i < size; i++){
        for(int j = 0; j < size; j++){
            // treasure is found, return
            pthread_mutex_lock(&mutex);
                if(found) {
                    pthread_mutex_unlock(&mutex);
                    return NULL;
                }
            pthread_mutex_unlock(&mutex);

            // wait for all threads to reach here, before we check for treasure
            pthread_barrier_wait(&barrier);
            if(grid[i][j] == '$'){
                pthread_mutex_lock(&mutex);
                    found = true;
                pthread_mutex_unlock(&mutex);
                printf("Thread at row %d found the treasure at %d,%d\n", row, i, j);
            } 
            
            // mark visited
            grid[i][j] = '#';

            pthread_barrier_wait(&barrier);

            // first thread will alone print the grid
            if(row == firstThreadRow){
                for(int i = 0; i < size; i++){
                    for(int j = 0; j < size; j++){
                        printf("%c ", grid[i][j]);
                    } printf("\n");
                } printf("\n");

                sleep(1);
            }
        }
    } return NULL;
}

int main(){
    do{
        printf("Enter size of NxN grid: ");
        scanf("%d", &size);
    } while(size < 0);

    int numthreads;
    do{
        printf("Enter num of threads : ");
        scanf("%d", &numthreads);
    } while(numthreads < 1 || numthreads > 8);

    do{
        printf("Enter row of treasure : ");
        scanf("%d", &ti);
    } while(ti < 0 || ti > size - 1);
    do{
        printf("Enter column of treasure : ");
        scanf("%d", &tj);
    } while(tj < 0 || tj > size - 1);

    for(int i = 0; i < size; i++){
        for(int j = 0; j < size; j++){
            grid[i][j] = '.';
        }
    }

    pthread_barrier_init(&barrier, NULL, numthreads);
    grid[ti][tj] = '$';             // treasure

    pthread_t threads[numthreads];
    int rows[numthreads];
    for(int i = 0; i < numthreads; i++){
        rows[i] = i;
        pthread_create(&threads[i], NULL, searchGrid, (void *)(&rows[i]));
        if(i == 0) firstThreadRow = rows[i];
    }

    for(int i = 0; i < numthreads; i++){
        pthread_join(threads[i], NULL);
    }

    pthread_barrier_destroy(&barrier);

    return 0;
}