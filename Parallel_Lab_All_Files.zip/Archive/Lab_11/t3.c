#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;

    int mat[4][4] = {
        {1,0,0,0},
        {0,1,0,0},
        {0,0,1,0},
        {0,0,0,1}
    };

    int vec[4] = {4,5,6,7};
    int row[4];
    int final_row[4];
    int product = 0;
    int final_sum;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    
    // Get the number of processes and the rank of the current process
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    MPI_Scatter(mat, 4, MPI_INT, row, 4, MPI_INT, 0, MPI_COMM_WORLD);

    // MPI_Barrier(MPI_COMM_WORLD);
    printf("Process %d received: ", rank);
    for(int i = 0 ;i < 4; i++){
        printf(" %d", row[i]);
    } printf("\n");


    for(int i = 0; i < 4; i++){
        product += row[i] * vec[i];
    }
    printf("Process %d computed %d\n", rank, product);

    // MPI_Barrier(MPI_COMM_WORLD);
    MPI_Gather(&product, 1, MPI_INT, final_row, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // MPI_Barrier(MPI_COMM_WORLD);
    MPI_Reduce(&product, &final_sum, 4, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
    if(rank == 0){
        printf("Result vector: ");
        for(int i=0;i<4;i++) printf("%d ", final_row[i]);
        printf("\n");
        printf("Computed result: %d\n", final_sum);
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}