#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int value = 42;  // The integer value to send from process 0
    int received_value;

    // Initialize MPI
    // MPI_Init(&argc, &argv);
    MPI_Init(NULL, NULL);
    
    // Get the number of processes and the rank of the current process
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    
    // Process 0 sends the value to Process 1
    if (rank == 0) {
        printf("Process 0 sending value %d to process 1\n", value);
        MPI_Send(&value, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);  // Send value to Process 1
    }
    
    // Process 1 receives the value
    if (rank == 1) {
        MPI_Recv(&received_value, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);  // Receive value from Process 0
        printf("Process 1 received value %d from process 0\n", received_value);
    }

    if(rank != 0 && rank != 1){
        printf("Process %d called\n", rank);
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}
