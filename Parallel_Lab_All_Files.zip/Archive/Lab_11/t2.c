#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int value = 42;  // Value to send from process 0
    int received_value;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    
    // Get the number of processes and the rank of the current process
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    int data[] = {1,2,3,4,5,6,7,8};
    
    // Process 0 sends a value to Process 1
    if (rank == 0) {
        printf("Process 0 sending value %d to process 1\n", value);
        for(int i = 1; i < size; i++){
            MPI_Send(&data, i, MPI_INT, i, 0, MPI_COMM_WORLD);  // Send value to Process 1
        }
    } else{
        MPI_Status status;
        
        // Probe for a message from process 0 with tag 0
        MPI_Probe(0, 0, MPI_COMM_WORLD, &status);
        
        // After probing, get the size of the incoming message
        int message_size;
        MPI_Get_count(&status, MPI_INT, &message_size);

        int rcv_data[message_size];
        
        // Print the details of the incoming message
        printf("Process %d: detected a message from process %d with size %d integers\n",
               rank, status.MPI_SOURCE, message_size);

        // Now receive the message
        MPI_Recv(&rcv_data, message_size, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process %d received from process 0: ", rank);
        for(int i = 0; i < message_size; i++){
            printf(" %d", rcv_data[i]);
        } printf("\n");
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}