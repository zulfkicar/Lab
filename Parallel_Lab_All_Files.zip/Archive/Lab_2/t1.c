#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <limits.h>

int *array;
int num_threads;
int array_size;
char max_min;
int global_result;
pthread_mutex_t lock;

void *find_max_min(void *arg)
{
    int thread_id = *(int *)arg;
    int start = thread_id * (array_size / num_threads);
    int end = (thread_id == num_threads - 1) ? array_size : start + (array_size / num_threads);

    int local_result = (max_min == 'm') ? INT_MAX : INT_MIN;

    for (int i = start; i < end; i++)
    {
        if (max_min == 'm')
        {
            if (array[i] < local_result)
                local_result = array[i];
        }
        else
        {
            if (array[i] > local_result)
                local_result = array[i];
        }
    }

    pthread_mutex_lock(&lock);
    if (max_min == 'm')
    {
        if (local_result < global_result)
            global_result = local_result;
    }
    else
    {
        if (local_result > global_result)
            global_result = local_result;
    }
    pthread_mutex_unlock(&lock);

    return NULL;
}

void multithreaded_find_max_min()
{
    pthread_t threads[num_threads];
    int thread_ids[num_threads];

    global_result = (max_min == 'm') ? INT_MAX : INT_MIN;

    for (int i = 0; i < num_threads; i++)
    {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, find_max_min, &thread_ids[i]);
    }

    for (int i = 0; i < num_threads; i++)
    {
        pthread_join(threads[i], NULL);
    }
}

int sequential_find_max_min()
{
    int result = (max_min == 'm') ? INT_MAX : INT_MIN;

    for (int i = 0; i < array_size; i++)
    {
        if (max_min == 'm')
        {
            if (array[i] < result)
                result = array[i];
        }
        else
        {
            if (array[i] > result)
                result = array[i];
        }
    }

    return result;
}

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage: %s <array_size> <num_threads> <max_min>\n", argv[0]);
        printf("max_min: 'm' for minimum, 'M' for maximum\n");
        return -1;
    }

    array_size = atoi(argv[1]);
    num_threads = atoi(argv[2]);
    max_min = argv[3][0];

    // Allocate memory for the array and fill it with random values
    array = (int *)malloc(array_size * sizeof(int));
    srand(time(NULL));
    for (int i = 0; i < array_size; i++)
    {
        array[i] = rand() % 10000; // Random values between 0 and 9999
    }

    // Measure time for sequential execution
    clock_t start_time = clock();
    int seq_result = sequential_find_max_min();
    clock_t end_time = clock();
    double seq_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;

    // Measure time for multithreaded execution
    pthread_mutex_init(&lock, NULL);
    start_time = clock();
    multithreaded_find_max_min();
    end_time = clock();
    double mt_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    pthread_mutex_destroy(&lock);

    // Print the results
    printf("Sequential result: %d, time: %.6f seconds\n", seq_result, seq_time);
    printf("Multithreaded result: %d, time: %.6f seconds\n", global_result, mt_time);

    // Clean up
    free(array);

    return 0;
}
