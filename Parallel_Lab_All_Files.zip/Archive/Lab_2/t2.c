#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

int **A, **B, **C;
int N, M, N1, M1;
int num_threads;

typedef struct
{
    int row_start;
    int row_end;
} thread_data;

void *multiply_matrices(void *arg)
{
    thread_data *data = (thread_data *)arg;
    for (int i = data->row_start; i < data->row_end; i++)
    {
        for (int j = 0; j < M1; j++)
        {
            C[i][j] = 0;
            for (int k = 0; k < M; k++)
            {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return NULL;
}

void sequential_multiply()
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M1; j++)
        {
            C[i][j] = 0;
            for (int k = 0; k < M; k++)
            {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void multithreaded_multiply()
{
    pthread_t threads[num_threads];
    thread_data thread_args[num_threads];

    int rows_per_thread = N / num_threads;
    int leftover_rows = N % num_threads;

    for (int i = 0; i < num_threads; i++)
    {
        thread_args[i].row_start = i * rows_per_thread;
        thread_args[i].row_end = (i + 1) * rows_per_thread;
        if (i == num_threads - 1)
        {
            thread_args[i].row_end += leftover_rows;
        }
        pthread_create(&threads[i], NULL, multiply_matrices, &thread_args[i]);
    }

    for (int i = 0; i < num_threads; i++)
    {
        pthread_join(threads[i], NULL);
    }
}

void read_matrices(FILE *file)
{
    fscanf(file, "%d %d", &N, &M); // Read size of matrix A
    printf("N,M = %d %d\n", N, M);
    A = (int **)malloc(N * sizeof(int *));
    for (int i = 0; i < N; i++)
    {
        A[i] = (int *)malloc(M * sizeof(int));
        for (int j = 0; j < M; j++)
        {
            fscanf(file, "%d", &A[i][j]);
        }
    }

    fscanf(file, "%d %d", &N1, &M1); // Read size of matrix B
    B = (int **)malloc(N1 * sizeof(int *));
    for (int i = 0; i < N1; i++)
    {
        B[i] = (int *)malloc(M1 * sizeof(int));
        for (int j = 0; j < M1; j++)
        {
            fscanf(file, "%d", &B[i][j]);
        }
    }

    // Initialize matrix C to store the result
    C = (int **)malloc(N * sizeof(int *));
    for (int i = 0; i < N; i++)
    {
        C[i] = (int *)malloc(M1 * sizeof(int));
    }
}

void print_matrix(int **matrix, int rows, int cols)
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("Usage: %s <input_file> <num_threads>\n", argv[0]);
        return -1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL)
    {
        printf("Error opening input file.\n");
        return -1;
    }

    int test_cases;
    fscanf(file, "%d", &test_cases);

    double total_seq_time = 0.0;
    double total_mul_time = 0.0;
    while (test_cases--)
    {
        num_threads = atoi(argv[2]);

        // Read matrices A and B
        read_matrices(file);
        printf("Matrix A:\n");
        print_matrix(A, N, M);
        printf("Matrix B:\n");
        print_matrix(B, N1, M1);

        if (M != N1)
        {
            printf("%d %d", M, N1);
            printf("Matrix multiplication is not possible with given matrices (A columns != B rows).\n");
            return -1;
        }

        // Measure time for sequential multiplication
        clock_t start_time = clock();
        sequential_multiply();
        clock_t end_time = clock();
        double seq_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
        total_seq_time += seq_time;

        // Print result for sequential multiplication
        printf("Sequential multiplication result:\n");
        print_matrix(C, N, M1);

        // Reset matrix C for multithreaded multiplication
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < M1; j++)
            {
                C[i][j] = 0;
            }
        }

        // Measure time for multithreaded multiplication
        start_time = clock();
        multithreaded_multiply();
        end_time = clock();
        double mt_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
        total_mul_time += mt_time;

        // Print result for multithreaded multiplication
        printf("Multithreaded multiplication result:\n");
        print_matrix(C, N, M1);

        // Free allocated memory
        for (int i = 0; i < N; i++)
        {
            free(A[i]);
            free(C[i]);
        }
        free(A);
        free(C);

        for (int i = 0; i < N1; i++)
        {
            free(B[i]);
        }
        free(B);
        printf("--------\n");
    }
    fclose(file);

    printf("Time taken for all sequential multiplication: %.6f seconds\n", total_seq_time);
    printf("Time taken for all multithreaded multiplication: %.6f seconds\n", total_mul_time);

    return 0;
}
