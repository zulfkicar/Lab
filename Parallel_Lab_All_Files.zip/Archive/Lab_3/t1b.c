#include <stdio.h>
#include <pthread.h>

// Shared variable and mutex for synchronization
int shared_counter = 0;
pthread_mutex_t counter_mutex; 

// Function to increment the counter 100,000 times in a thread-safe manner
void* safe_increment(void* arg) {
    for (int i = 0; i < 100000; ++i) {
        pthread_mutex_lock(&counter_mutex); // Acquire the lock
        shared_counter++; // Update the shared counter
        pthread_mutex_unlock(&counter_mutex); // Release the lock
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Initialize the mutex before starting threads
    pthread_mutex_init(&counter_mutex, NULL);

    // Start two threads to increment the counter
    pthread_create(&thread1, NULL, safe_increment, NULL);
    pthread_create(&thread2, NULL, safe_increment, NULL);

    // Wait for both threads to finish execution
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Display the final value of the shared counter
    printf("Counter value after using mutex: %d\n", shared_counter);

    // Clean up the mutex resource
    pthread_mutex_destroy(&counter_mutex);

    return 0;
}
