#include <stdio.h>
#include <pthread.h>

// Number of threads
#define NUM_THREADS 4

// Declare the barrier
pthread_barrier_t barrier;

// Function for each thread to run
void* perform_task(void* arg) {
    int thread_num = *(int*)arg;

    // Each thread sleeps for a different time but they will get synchronized later by use of barrier
    printf("Thread %d sleeping for %d seconds before reaching barrier.\n", thread_num, thread_num + 1);
    sleep(thread_num + 1);

    // Task before reaching the barrier
    printf("Thread %d performing task before barrier.\n", thread_num);
    
    // Wait at the barrier for all threads to reach this point
    pthread_barrier_wait(&barrier);

    // Task after all threads have passed the barrier
    printf("Thread %d performing task after barrier.\n", thread_num);

    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];

    // Initialize the barrier to wait for 4 threads
    pthread_barrier_init(&barrier, NULL, NUM_THREADS);

    // Create four threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, perform_task, &thread_ids[i]);
    }

    // Wait for all threads to finish
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    // Destroy the barrier after all threads have completed
    pthread_barrier_destroy(&barrier);

    return 0;
}
