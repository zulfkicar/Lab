#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

// Number of threads
#define NUM_THREADS 4

// Declare the barrier
pthread_barrier_t barrier;

// Declare the mutex
pthread_mutex_t mutex; 

#define N 4

// matrix
// int a[N][N];
// int b[N][N];
int a[N][N] = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
int b[N][N] = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};;
int c[N][N];

// Function for each thread to run
void* perform_task(void* arg) {
    int thread_num = *(int*)arg;
    int i = thread_num;

    for(int j = 0; j < N; j++){
        c[i][j] = 0;
        for(int k = 0; k < N; k++){
            pthread_mutex_lock(&mutex); // Acquire the lock
            c[i][j] += a[i][k] * b[k][j];
            pthread_mutex_unlock(&mutex); // Release the lock
        }
    }

    printf("Row %d of Matrix C is calculated, waiting for others.\n", i);

    // Wait at the barrier for all threads to reach this point
    pthread_barrier_wait(&barrier);

    return NULL;
}

void printMatrix(int a[N][N], const char* name){
    printf("Matrix %s: \n", name);
    for(int i = 0; i < N; i++){
        printf("[");
        for(int j = 0; j < N; j++){
            printf("%d", a[i][j]);
            if(j != N-1) printf(" ");
        }
        printf("]\n");
    }
    printf("\n");
}

int main() {
    srand(time(NULL));

    // for(int i = 0; i < N; i++){
    //     for(int j = 0; j < N; j++){
    //         a[i][j] = rand() % 6;
    //         b[i][j] = rand() % 6;
    //     }
    // }

    printMatrix(a, "A");
    printMatrix(b, "B");
    
    pthread_t threads[N];
    int thread_ids[N];

    // Initialize the barrier to wait for 4 threads
    pthread_barrier_init(&barrier, NULL, N);
        // Initialize the mutex before starting threads
    pthread_mutex_init(&mutex, NULL);


    // Create four threads
    for (int i = 0; i < N; ++i) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, perform_task, &thread_ids[i]);
    }

    // Wait for all threads to finish
    for (int i = 0; i < N; ++i) {
        pthread_join(threads[i], NULL);
    }

    printMatrix(c, "Product C");

    // Destroy the barrier after all threads have completed
    pthread_barrier_destroy(&barrier);

    // Clean up the mutex resource
    pthread_mutex_destroy(&mutex);

    return 0;
}
