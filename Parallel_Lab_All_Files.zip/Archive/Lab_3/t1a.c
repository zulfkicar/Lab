#include <stdio.h>
#include <pthread.h>

// Shared variable that will be updated by both threads
int shared_counter = 0;

// Thread function to increment the shared variable 100,000 times
void* increment(void* arg) {
    for (int i = 0; i < 100000; ++i) {
        shared_counter++; // Increase the shared counter
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Launch two separate threads
    pthread_create(&thread1, NULL, increment, NULL);
    pthread_create(&thread2, NULL, increment, NULL);

    // Wait for both threads to complete
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Print the final value of the shared counter
    printf("Resulting counter value (without synchronization): %d\n", shared_counter);

    return 0;
}
